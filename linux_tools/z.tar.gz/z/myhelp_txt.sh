
myhelp()
{
	echo "-c  :(child)将匹配限制到当前目录的子目录."
	echo "-e  :(echo)输出最佳匹配，而不是cd."
	echo "-l  :list only"
	echo "-r  :(rank)仅按级别匹配."
	echo "-t  :()仅按最近访问进行匹配."
	echo "-x  :()从数据文件中删除当前目录."

	return 0
}

