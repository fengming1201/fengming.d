#!/bin/bash 
#
#patch update log
#advcpmv-0.8-8.31.patch   
#advcpmv-0.8-8.32.patch   //fix progressbars not showing when moving files and global progress. April 3, 2022 21:05
#advcpmv-0.9-9.0.patch    //fix progressbars not showing when moving files and global progress. April 3, 2022 21:05
#advcpmv-0.9-9.1.patch   //Tweak line numbers. June 4, 2022 10:31
#
set -e

if [ $# -gt 1 ]
then
    echo "$0  [cpmv_version]  //default:auto get from current system."
    exit 1
fi

if [ $# -eq 1 ]
then
    #user input 
    tool_version=$1
else
    #get from current system
    tool_version=$(cp --version  | grep -w cp  | awk '{print $4 }')
fi

patch_vers=""
case ${tool_version} in
    "8.31")
        patch_vers=0.8
        ;;
    "8.32")
        patch_vers=0.8
        ;;
    "9.0")
        patch_vers=0.9
        ;;
    "9.1")
        patch_vers=0.9
        ;;
    *)
        echo "unknow version!!"
        echo "8.31 or 8.32 or 9.0 or 9.1"
        exit 1
        ;;
esac

tools_version_pack=coreutils-${tool_version}.tar.xz
tools_version_dir=coreutils-${tool_version}
patch_version_file=advcpmv-${patch_vers}-${tool_version}.patch

#download src
if [ ! -f ${tools_version_pack} ]
then
    echo "download ${tools_version_pack}  ....."
    echo "curl -LO http://ftp.gnu.org/gnu/coreutils/${tools_version_pack}"
    curl -LO http://ftp.gnu.org/gnu/coreutils/${tools_version_pack}
    if [ $? -ne 0 ];then echo "ERROR:download fail.line:${LINENO}";exit 1;fi
fi
#download patch
if [ ! -f ${patch_version_file} ]
then
    echo "download ${patch_version_file} ....."
    echo "curl -LO https://raw.githubusercontent.com/jarun/advcpmv/master/${patch_version_file}"
    curl -LO https://raw.githubusercontent.com/jarun/advcpmv/master/${patch_version_file}
    if [ $? -ne 0 ];then echo "ERROR:download fail.line:${LINENO}";exit 2;fi
fi
#delete old version dir
if [ -d ${tools_version_dir} ]
then 
    echo "remove old version ${tools_version_dir}"
    rm -rf ${tools_version_dir}
fi
#extra pgk
if [ -f ${tools_version_pack} ]
then
    tar -xvJf ${tools_version_pack}
    if [ $? -ne 0 ];then echo "ERROR:tar fail.line:${LINENO}";exit 3;fi
fi

if [ ! -d ${tools_version_dir} ];then echo "ERROR:${tools_version_dir} not exist,line:${LINENO}";exit 4;fi
cd ${tools_version_dir}
patch -p1 -i ../${patch_version_file}
./configure
make
if [ $? -ne 0 ];then echo "ERROR:make fail.line:${LINENO}";exit 5;fi
cd -
echo "compile result files in ${tools_version_dir}/src/ dir"
if [ -f ${tools_version_dir}/src/cp ] && [ -f ${tools_version_dir}/src/mv ]
then
    ls -lh ${tools_version_dir}/src/cp
    ls -lh ${tools_version_dir}/src/mv
else
    echo "ERROR:compile fail. "
fi
echo ""
echo "all done ....."

exit 0
